package br.com.fiap.jpa.service.impl;

import java.util.List;

import br.com.fiap.entity.Livro;
import br.com.fiap.jpa.dao.impl.LivroDAOImpl;
import br.com.fiap.jpa.service.GenericService;

public class LivroServiceImpl extends GenericService<Livro, Long>{

	private static LivroServiceImpl instance = null;
	private LivroDAOImpl LivroDAO;

	private LivroServiceImpl() {
		LivroDAO = LivroDAOImpl.getInstance();
	}
	

	public static LivroServiceImpl getInstance() {
		if (instance == null) {
			instance = new LivroServiceImpl();
		}
		return instance;
	}
	
	@Override
	public void inserir(Livro instance) {
		try {
			LivroDAO.salvar(instance, getEntityManager());
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		} finally {
			closeEntityManager();
		}
	}
	

	@Override
	public void atualizar(Livro instance) {
		try {
			LivroDAO.atualizar(instance, getEntityManager());
		}catch(Exception e){
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		}finally {
			closeEntityManager();
		}
	}

	@Override
	public void remover(Long id) {
		try {
			LivroDAO.remover(id, getEntityManager());
		}catch(Exception e){
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		}finally {
			closeEntityManager();
		}
	}
	
	
	@Override
	public Livro obter(Long id) {
		Livro livro = null;
		try {
			livro = LivroDAO.obterPorId(id, getEntityManager());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeEntityManager();
		}
		return livro;
	}

	@Override
	public List<Livro> listar() {
		List<Livro> livro = null;
		try {
			livro = LivroDAO.listar(getEntityManager());
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeEntityManager();
		}
		return livro;
	}

}
