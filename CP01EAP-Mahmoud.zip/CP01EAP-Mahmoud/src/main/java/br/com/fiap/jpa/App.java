package br.com.fiap.jpa;

import java.time.LocalDate;

import br.com.fiap.entity.Livro;
import br.com.fiap.jpa.service.impl.LivroServiceImpl;

public class App {

	public static void main(String[] args) {
		LivroServiceImpl livroService = LivroServiceImpl.getInstance();
		
		livroService.inserir(new Livro("As Cr�nicas da Morte em Java.class", "Clarice Lispector", 200102, LocalDate.of(20, 05, 2000)));
		livroService.inserir(new Livro("A morte do Python", "Mahmoud", 202203, LocalDate.of(20, 02, 2003)));
		livroService.inserir(new Livro("O passado de Shark Tank", "Gabriel", 202017, LocalDate.of(04, 04, 2020)));
		
		Livro livro = livroService.obter(1L);
		
		System.out.println(livro);
		

	}

}
